import yfinance as yf


def load_market_data(tickers, start_date, end_date):

    data = yf.download(
        tickers,
        start=start_date,
        end=end_date
    )['Adj Close']

    returns = data.pct_change().dropna()

    return data, returns
