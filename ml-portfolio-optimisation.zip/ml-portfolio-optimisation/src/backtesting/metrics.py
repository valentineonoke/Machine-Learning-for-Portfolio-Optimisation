import numpy as np


def sharpe_ratio(returns, risk_free_rate=0.02):
    excess_returns = returns - risk_free_rate / 252

    return np.sqrt(252) * excess_returns.mean() / excess_returns.std()


def max_drawdown(cumulative_returns):
    running_max = np.maximum.accumulate(cumulative_returns)

    drawdown = cumulative_returns / running_max - 1

    return drawdown.min()
