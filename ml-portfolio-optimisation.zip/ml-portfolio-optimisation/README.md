# Machine Learning for Portfolio Optimisation

A comprehensive quantitative finance and machine learning framework for:

- Portfolio Optimisation
- Risk Management
- Asset Allocation
- Return Forecasting
- Backtesting
- Reinforcement Learning Strategies

## Technologies
- Python
- Scikit-learn
- PyTorch
- TensorFlow
- XGBoost
- CVXPY
- PyPortfolioOpt
